/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-09 14:24:00
 * @LastEditTime: 2019-08-09 14:25:39
 * @LastEditors: Please set LastEditors
 */
$(function () {
    $('[data-toggle="popover"]').popover();
})