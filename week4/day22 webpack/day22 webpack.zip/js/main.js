import "../css/main.css";
import $ from "jquery";

$(document).ready(function () {

});