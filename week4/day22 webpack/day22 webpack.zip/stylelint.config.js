/* eslint-disable no-undef */
module.exports = {
    extends: "stylelint-config-standard",
    rules: {
        indentation: null,
        "no-missing-end-of-source-newline": null
    }
};